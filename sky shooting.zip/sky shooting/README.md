# Unity-2D-Shooting-Game

This Unity Project developed on Unity 5.2.2f1(64-bit)

It's just a implementation base on this tutorial: [Creating a 2D game with Unity](http://pixelnest.io/tutorials/2d-game-unity/)

Exported WebGL demo hosted on [Crazyatom website](http://unity-2d-shooting-game.crazyatom.com/)
